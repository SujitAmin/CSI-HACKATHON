# Warzone
CSI Hackathon 2018 at Fr. Conceicao Rodrigues Institute of  Technology in Collaboration with Myraa Technologies with Innovation Groups hacking through the Warzone Battle

https://docs.google.com/document/d/1gRmzrFsFGyo7WIgi5NjaNpC0dyE0q8QEcHYrNiMpjT0/edit?usp=sharing
